export interface Usuario{
    idUsuario: number;
	nombre: string;
	apellido1: string;
	apellido2: string;
	correo: string;
	password: string;
	num_denuncias: number;
	idTipoUsuario: number;
	instPseudonimo: string;
	admin_id:number;
	prof_id:number;
	tutor_id:number;

}
