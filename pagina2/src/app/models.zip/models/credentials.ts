export interface Credentials{
	correo: String;
	password: string;
}
