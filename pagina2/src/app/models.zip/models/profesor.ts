export interface Profesor{
    idProfesor: number,
    correoContacto: String,
    institucion:String,
    numFaltasTotales:number
}
