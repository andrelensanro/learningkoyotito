export interface Tutorado{
    idTutorado: number;
    nivel: number;
    puntos:number;
    pseudonimo: string;
}