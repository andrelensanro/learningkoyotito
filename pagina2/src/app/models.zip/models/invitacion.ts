export interface Invitaciones{
    id_invitacion: number;
	url_invitacion: string;
}