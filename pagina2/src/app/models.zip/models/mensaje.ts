export interface Mensaje{
    tipo:number;
    mensaje:string;
}